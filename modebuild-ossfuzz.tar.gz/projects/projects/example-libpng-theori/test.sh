#!/bin/bash

# build CP source - for running tests
./configure
make all test