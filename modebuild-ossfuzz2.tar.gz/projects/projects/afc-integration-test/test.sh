#!/bin/sh

make test